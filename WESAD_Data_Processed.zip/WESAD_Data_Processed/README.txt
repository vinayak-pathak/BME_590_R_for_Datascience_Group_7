Conditions for Participants Labels.
0 = Rest
1 = Baseline
2 = TSST/Stress
3 = Amusement
4 = Meditation
5  = base Read
6  = Slow Read
7  = fast Read

For each patient we extracted rolling average at a resolution of 1 second. For the chest worn dataset.(Respbian)
Total data points = 44953
Number of patients =15
PIDs = (2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14, 15, 17)