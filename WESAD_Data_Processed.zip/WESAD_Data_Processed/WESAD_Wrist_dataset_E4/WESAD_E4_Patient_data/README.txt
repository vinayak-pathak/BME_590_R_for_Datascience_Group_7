Conditions for Participants
1 = Baseline
2 = TSST/Stress
3 = Amusement
4 = Meditation
5  = base Read
6  = Slow Read
7  = fast Read